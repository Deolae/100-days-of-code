print("The Love Calculator is calculating your score...")
name1 = input() # What is your name?
name2 = input() # What is their name?

name1 = name1.lower()
name2 = name2.lower()

# To work out the love score between two people:
# Take both people's names and check for the number of times the letters in the word TRUE occurs.
# Then check for the number of times the letters in the word LOVE occurs.
# Then combine these numbers to make a 2 digit number.

t_count = name1.count('t') + name2.count('t')
r_count = name1.count('r') + name2.count('r')
u_count = name1.count('u') + name2.count('u')
e_count = name1.count('e') + name2.count('e')
l_count = name1.count('l') + name2.count('l')
o_count = name1.count('o') + name2.count('o')
v_count = name1.count('v') + name2.count('v')
e_count = name1.count('e') + name2.count('e')

first_digit = t_count + r_count + u_count + e_count
second_digit = l_count + o_count + v_count + e_count

score = str(first_digit) + str(second_digit)
score = int(score)
if score < 10 or score > 90:
  print(f"Your score is {score}, you go together like coke and mentos.")
elif score >= 40 and score <=50:
  print(f"Your score is {score}, you are alright together.")
else:
  print(f"Your score is {score}.")
  